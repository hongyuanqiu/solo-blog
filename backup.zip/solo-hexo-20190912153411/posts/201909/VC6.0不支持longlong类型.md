title: VC++ 6.0 不支持long long 类型
date: '2019-09-12 12:24:51'
updated: '2019-09-12 12:24:51'
tags: [VC6.0, 数据类型]
permalink: /articles/2019/09/12/1568262291573.html
---
VC++ 6.0 不支持long long 类型 ; 使用 _int64 代替
报错提示
>error C2632: 'long' followed by 'long' is illegal  
error C2632: 'long' followed by 'long' is illegal
