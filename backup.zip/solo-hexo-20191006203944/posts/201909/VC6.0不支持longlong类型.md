title: VC++ 6.0 不支持long long 类型
date: '2019-09-12 12:24:51'
updated: '2019-09-16 13:56:17'
tags: [VC6.0, 数据类型]
permalink: /articles/2019/09/12/1568262291573.html
---
## VC6.0 不支持long long,使用__int64代替
VC++ 6.0 不支持long long 类型 ; 使用 __int64 代替
报错提示
>error C2632: 'long' followed by 'long' is illegal  
error C2632: 'long' followed by 'long' is illegal


格式化输出：
```c
printf("CPU循环周期 = %I64u \n",GetCpuCycle());
```

## 在Linux下格式化与 long long 输出；
```c
#ifdef _WIN32
	#include <winsock2.h>
	#include <time.h>
#else
	#include <sys/time.h>
#endif
 
#include <stdio.h>

// 定义64位整形
#if defined(_WIN32) && !defined(CYGWIN)
	typedef __int64   int64t;
#else
	typedef long long int64t;
#endif  // _WIN32

typedef struct MyTimeVal{
	int idx ;
	//timeval *tv[4];
	long tv_nsec;
}MyTimeVal;

// 获取系统的当前时间，单位微秒(us)
int64t GetSysTimeMicros()
{
#ifdef _WIN32
	// 从1601年1月1日0:0:0:000到1970年1月1日0:0:0:000的时间(单位100ns) 
	#define EPOCHFILETIME   (116444736000000000UL)
    FILETIME ft;
    LARGE_INTEGER li;
    int64t tt = 0;
    GetSystemTimeAsFileTime(&ft);
    li.LowPart = ft.dwLowDateTime;
    li.HighPart = ft.dwHighDateTime;
    // 从1970年1月1日0:0:0:000到现在的微秒数(UTC时间)
    tt = (li.QuadPart - EPOCHFILETIME) /10;
    return tt;
#else
	//throw "只支持Windows平台！";
    timeval tv;
    gettimeofday(&tv, 0);
    return (int64t)tv.tv_sec * 1000000 + (int64t)tv.tv_usec;
#endif // _WIN32
    return 0;
}

#ifdef _WIN32
//CPU自上电以来的时间周期数
__declspec (naked) unsigned __int64 GetCpuCycle( void )
{
	_asm
	{
		rdtsc
			ret
	}
}
#endif

//获取当前时间，单位是纳秒
int64t GetSysTimeNanos()
{
#ifdef _WIN32
	__int64 cpuCycle= GetCpuCycle() ;
	__int64 ns = cpuCycle - (cpuCycle / 1000 * 1000 );
	return	GetSysTimeMicros() * 1000  +  ns ;
#else
	return GetSysTimeMicros() * 1000;
#endif
}


int main(){

// 
// 	return 0;
//	LARGE_INTEGER nFreq;
//	LARGE_INTEGER t1;
//	LARGE_INTEGER t2;
//	double dt; 
//	QueryPerformanceFrequency(&nFreq);
//	QueryPerformanceCounter(&t1);

	for(int i = 0 ; i < 10; i ++){
		int64t ns = GetSysTimeNanos();
		printf( "%I64u\n" , ns );
		printf("%llu\n", ns);
	}

//	QueryPerformanceCounter(&t2); 
//	dt =(t2.QuadPart - t1.QuadPart)/(double)nFreq.QuadPart;
//	std::cout <<"Running time :"<< dt <<"秒"<< std::endl;
//	cout <<"Running time :"<< dt*1000000 <<"us"<< endl;
	return 1;
}

```
输出结果：
![图片.png](https://img.hacpai.com/file/2019/09/图片-59ff23d6.png)

