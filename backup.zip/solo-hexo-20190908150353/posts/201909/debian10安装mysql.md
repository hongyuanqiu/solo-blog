title: debian10安装mysql
date: '2019-09-08 14:53:41'
updated: '2019-09-08 14:53:41'
tags: [Note]
permalink: /articles/2019/09/08/1567925621588.html
---
#debian10安装mysql
文章摘自[Debian9安装MySQL](https://www.jianshu.com/p/40b770d86a7b)
## 配置apt-get源
debian下安装软件的指令为apt-get，在使用apt-get安装MySQL之前，需要先下载MySQL官网提供的DEB包，以将MySQL的仓库添加到apt-get的源中，打开网站[MySQL APT Respository](https://dev.mysql.com/downloads/repo/apt/), 下载刚刚的其中的源。
> 适用于Debian与Ubuntu

## 安装mysql的步骤

```bash
# 1. 查看最新包的地址,
https://dev.mysql.com/downloads/repo/apt/
# 2. wget下载deb源文件
wget https://repo.mysql.com//mysql-apt-config_0.8.13-1_all.deb
# 3. 更新deb的地址,打开后，选择[ok]
sudo dpkg -i ./mysql-apt-config_0.8.13-1_all.deb
# 4. 更新源地址
sudo apt-get update
# 5. 安装mysql
sudo apt-get install mysql-server
```

## 服务状态查看
```bash
# 查看状态
sudo systemctl status mysql
# 关闭服务
sudo systemctl status stop
# 重启服务
sudo systemctl status restart
```
## 方便开发的配置
```bash
# 以root用户登录
mysql -u root p
# 输入密码登录之后，适用如下指令新建一个用户
create user 'username'@'%' IDENTIFIED by 'password';
# 为用户分配权限, 并可以在任意主机上登录
GRANT ALL PRIVILEGES ON *.* TO 'username'@'%';
# 刷新权限
FLUSH PRIVILEGES;


```