title: 盘片插入驱动器cdrom
date: '2019-09-08 14:53:39'
updated: '2019-09-08 14:53:39'
tags: [Note]
permalink: /articles/2019/09/08/1567925619517.html
---
# 盘片插入驱动器“/media/cdrom/”再按「回车」键

>更换介质：请把标有
 “Debian GNU/Linux 10.0.0 _Buster_ - Official amd64 DVD Binary-1 20190706-10:2
的盘片插入驱动器“/media/cdrom/”再按「回车」键

## 1.修改source.list
```bash
nano /etc/apt/sources.list
```
## 2.注释信息源头
> [Linux版本收录的镜像](http://mirrors.ustc.edu.cn/help/debian.html)

```bash
# deb cdrom:[Debian GNU/Linux 10.0.0 _Buster_ - Official amd64 DVD Binary-1 20190706-10:24]/ buster contrib main
# 修改为国内的镜像
deb http://mirrors.163.com/debian/ jessie main non-free contrib
deb http://mirrors.163.com/debian/ jessie-updates main non-free contrib
deb-src http://mirrors.163.com/debian/ jessie main non-free contrib
deb-src http://mirrors.163.com/debian/ jessie-updates main non-free contrib
deb http://mirrors.163.com/debian-security/ jessie/updates main non-free contrib
deb-src http://mirrors.163.com/debian-security/ jessie/updates main non-free contrib

deb http://mirrors.ustc.edu.cn/debian/ jessie main non-free contrib
deb https://mirrors.tuna.tsinghua.edu.cn/debian/ jessie main non-free contrib
```



## 3.现在可以快乐执行更新
```bash
sudo apt-get install xfce4
```

# Debian10 安装图像界面

```bash
sudo apt-get install xorg xdm xfce4
```
1234