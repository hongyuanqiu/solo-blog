title: debian10 配置ssh允许root远程登录
date: '2019-09-08 00:37:23'
updated: '2019-09-08 00:37:23'
tags: [Debain, Linux, SSH]
permalink: /articles/2019/09/08/1567927442024.html
---
# debian10 配置ssh允许root远程登录
1. 安装ssh-service
```bash
apt-get install ssh
```
2.修改配置文件
```bash
vim /etc/ssh/sshd_config
```
3.修改如下
```bash
PermitRootLogin yes
```
4.重启服务
```bash
systemctl restart ssh
```