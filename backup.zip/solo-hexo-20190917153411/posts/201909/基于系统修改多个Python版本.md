title: 基于系统修改多个Python版本
date: '2019-09-08 00:37:23'
updated: '2019-09-08 00:37:23'
tags: [Debain, Linux, Python, 版本控制]
permalink: /articles/2019/09/08/1567927439523.html
---
# 基于系统修改多个Python版本

## 前情提要
> 在Linux里面有多个python环境，但是常用的是python使用的Python2，我需要使用python3的环境
## 使用 update-alternatives 指令来设置
```bash
# python 环境变量列表
update-alternatives  --list python
```

> update-alternatives: 错误: 无 python 的候选项
>> **表示没有把python环境加入到环境中**

## update-alternatives 注册环境
```bash
#查看环境信息
ls /usr/bin/python*
#注册环境
update-alternatives --install /usr/bin/python /usr/bin/python2 python 1
update-alternatives --install /usr/bin/python /usr/bin/python3 python 2
```

update-alternatives --install [链接] [名称] [路径] [优先级]

**参数信息**

- 链接 : 注册服务名
- 名称 : 注册最终地址，成功后将会把命令在这个固定的目的地址做真实命令的软链，以后管理就是管理这个软链；
- 路径 : 服务名，以后管理时以它为关联依据;
- 优先级 : 优先级，数字越大优先级越高。

## 查看已注册
```bash
update-alternatives --display python
```

update-alternatives