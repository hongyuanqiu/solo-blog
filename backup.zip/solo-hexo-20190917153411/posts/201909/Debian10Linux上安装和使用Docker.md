title: Debian 10 Linux上安装和使用Docker
date: '2019-09-08 00:37:23'
updated: '2019-09-08 00:37:23'
tags: [Debian, Docker, Linux, 操作系统]
permalink: /articles/2019/09/08/1567927441202.html
---
# Debian 10 Linux上安装和使用Docker
参考地址：
- [Debian10上安装和使用Docker](https://www.linuxidc.com/Linux/2019-08/159839.htm)
- [Debian 10 Buster上安装Docker和Docker Compose的方法](https://ywnz.com/linuxjc/4634.html)


Docker 是一个容器化平台，允许您快速构建，测试和部署应用程序，作为便携式，自给自足的容器，几乎可以在任何地方运行。
在本教程中，我们将解释如何在 Debian 10 Buster 上安装 Docker 并探索基本的 Docker 概念和命令。
1. 安装依赖包
安装通过 HTTPS 添加新存储库所需的软件包：
```bash
sudo apt update
sudo apt install apt-transport-https ca-certificates curl software-properties-common gnupg2
```
2. 添加Docker的官方GPG密钥
导入用于签署Docker包的Docker GPG密钥：
```bash
curl -fsSL https://download.docker.com/linux/debian/gpg |  sudo apt-key add -
```
成功后，命令将返回 OK 。
3. 将Docker存储库添加到Debian10
将稳定的 Docker APT 存储库添加到系统的软件存储库列表中：
```bash
#查看系统版本号
lsb_release -cs
#把地址添加到库
sudo add-apt-repository \
"deb [arch=amd64] https://download.docker.com/linux/debian \
$(lsb_release -cs) \
stable"
```
此命令将添加/etc/apt/sources.list文件中显示的行：
deb [arch=amd64] https://download.docker.com/linux/debian buster stable
4. 在Debian 10上安装Docker和Docker Compose
```bash
# 更新apt包索引
sudo apt update
# Docker CE和Docker Compose：
sudo apt -y install docker-ce docker-compose
# 此安装将在没有任何用户的情况下将docker组添加到系统，将你的用户帐户添加到组以作为非特权用户运行
#docker 命令：
sudo usermod -aG docker $USER
#注销并重新登录，以便重新评估你的组成员身份：
exit
```
5. 测试Docker安装
```bash
# 此命令，会下载测试镜像，在容器中运行
docker container run hello-world

#运行测试docker容器：
docker run --rm -it  --name test alpine:latest /bin/sh
#输出
# Unable to find image 'alpine:latest' locally
# latest: Pulling from library/alpine
# 9d48c3bd43c5: Pull complete
# Digest:  sha256:72c42ed48c3a2db31b7dafe17d275b634664a708d901ec9fd57b1529280f01fb
# Status: Downloaded newer image for alpine:latest
# Unable to find image 'alpine:latest' locally
# latest: Pulling from library/alpine
# cd784148e348: Pull complete
# Digest: sha256:46e71df1e5191ab8b8034c5189e325258ec44ea
# Status: Downloaded newer image for alpine:latest

cat /etc/os-release
#输出
# NAME="Alpine Linux"
# ID=alpine
# VERSION_ID=3.9.2
# PRETTY_NAME="Alpine Linux v3.9"
# HOME_URL="http://alpinelinux.org"
# BUG_REPORT_URL="http://bugs.alpinelinux.org"

#退出
exit
```
6. 测试Docker Compose安装
```bash
#  创建一个测试Docker Compose文件：
vim docker-compose.yml
```

```yaml
version: '3'

services:
  wordpress:
    image: wordpress
    ports:
      - 8080:80
    environment:
      WORDPRESS_DB_HOST: mysql
      WORDPRESS_DB_PASSWORD: root
    networks:
      - my-bridge

  mysql:
    image: mysql
    environment:
      MYSQL_ROOT_PASSWORD: root
      MYSQL_DATABASE: wordpress
    volumes:
      - mysql-data:/var/lib/mysql
    networks:
      - my-bridge
volumes:
  mysql-data:
networks:
  my-bridge:
    driver: bridge
```